<?php
function getDataFromDB($sql){
	$conn = mysqli_connect("localhost", "root", "","hashbase");
	//echo $sql;
	$result = mysqli_query($conn, $sql)or die(mysqli_error($$conn));
	$arr=array();
	//print_r($result);
	while($row = mysqli_fetch_assoc($result)) {
		$arr[]=$row;
	}
	return $arr;
}

if(isset($_REQUEST["price"])){
    //$conn = mysqli_connect("localhost", "root", "","hashbase");
	$sql="select * from bookTable where price >'".$_REQUEST['price']."'";
	$a=getDataFromDB($sql);
	//echo "<pre>";print_r($a);echo "<pre>";
	foreach($a as $v)
    {
		echo "<p>".$v["book_title"]." price ".$v["price"]."</p>";
	   }
    }




 ?>
