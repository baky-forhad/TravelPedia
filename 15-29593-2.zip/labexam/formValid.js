function isValid()
{
    var isValidSubmit = false;
    var author = document.getElementById('author').value;
    var price = parseInt(document.getElementById('price').value);


    if(author =='Herbet')
    {
        isValidSubmit=true;
        return isValidSubmit;
    }
    else
    {
        if(author.length<5)
        {
            return isValidSubmit;
        }
        else
        {
            if(price<100 || price >500 )
            {
                return isValidSubmit;
            }
            else
            {
                isValidSubmit=true;
                return isValidSubmit;

            }
        }


    }
}

function showHint() {
	var str=parseInt(document.getElementById('price').value);
	//document.getElementById("spinner").style.visibility= "visible";
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
			//alert(xmlhttp.responseText);
			//document.getElementById("spinner").style.visibility= "hidden";
		}
	};
	var url="db.php?price="+str;
	//var url="db.php";
	//alert(url);
	xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("price="+str);
}
