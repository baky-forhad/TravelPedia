<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>form</title>
    </head>
    <body>
        <?php include 'db.php'; ?>
        <h3 align="center">form validation</h3>
        <hr><hr><hr>
        <form class="" action="index.html" method="post" onsubmit="return isValid()">

            <span>author name :</span> <input type="text" id="author" value=""><br>
            <span>price :</span> <input type="text" id="price" value=""  onkeyup="showHint()" ><br>
            <p><span id="txtHint"></span></p>
            <input type="submit" name="submit" value="submit">
        </form>




        <script src="formValid.js"></script>




    </body>
</html>
